package com.sunspoter.cs.engine;

public class HandlerNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public HandlerNotFoundException() {
		// TODO Auto-generated constructor stub
		this("Handler can not be found.");
	}
	public HandlerNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
