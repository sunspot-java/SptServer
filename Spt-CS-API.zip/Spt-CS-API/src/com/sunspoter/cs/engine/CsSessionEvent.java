package com.sunspoter.cs.engine;

import java.util.EventObject;

/**
 * �Ự�¼�
 * @author Sunspot
 *
 */
public class CsSessionEvent extends EventObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CsSessionEvent(ICsSession session) {
		// TODO Auto-generated constructor stub
		super(session);
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
}
