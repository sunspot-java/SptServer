package com.sunspoter.cs.engine;

import java.util.EventObject;

/**
 * @author Sunspot
 * �������¼�
 */
public class CsContextEvent extends EventObject {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ICsSession session;
	private ICsDispatcher dispatcher;
	private ICsFilter filter;
	private ICsHandler handler;
	private int type;
	public CsContextEvent(ICsContext source,Integer type) {
		this(source,null,null,null,null,type);
	}
	public CsContextEvent(ICsContext source, ICsSession session,Integer type) {
		this(source,session,null,null,null,type);
	}
	public CsContextEvent(ICsContext source, ICsDispatcher dispatcher,Integer type) {
		this(source,null,dispatcher,null,null,type);
	}
	public CsContextEvent(ICsContext source, ICsFilter filter,Integer type) {
		this(source,null,null,filter,null,type);
	}
	public CsContextEvent(ICsContext source, ICsHandler handler,Integer type) {
		this(source,null,null,null,handler,type);
	}
	public CsContextEvent(ICsContext source, ICsSession session,
			ICsDispatcher dispatcher, ICsFilter filter, ICsHandler handler,Integer type) {
		super(source);
		this.session = session;
		this.dispatcher = dispatcher;
		this.filter = filter;
		this.handler = handler;
		this.type = type;
	}
	public ICsSession getSession() {
		return session;
	}
	public ICsDispatcher getDispatcher() {
		return dispatcher;
	}
	public ICsFilter getFilter() {
		return filter;
	}
	public ICsHandler getHandler() {
		return handler;
	}
	
	public int getType() {
		return type;
	}
	
	/**
	 * �����Ĵ���
	 */
	public static final int CONTEXT_INIT_TRIGGERED = 0x0091;
	
	/**
	 * ����������
	 */
	public static final int CONTEXT_DESTORY_TRIGGERED = 0x0092;
	/**
	 * ת������ʼ��
	 */
	public static final int DISPATCHER_INIT_TRIGGERED = 0x001;
	
	/**
	 * ת�������ٷ���
	 */
	public static final int DISPATCHER_DESTORY_TRIGGERED = 0x002;
	
	/**
	 * ����������
	 */
	public static final int FILTER_INIT_TRIGGERED = 0x021;
	
	/**
	 * ����������
	 */
	public static final int FILTER_DESTORY_TRIGGERED = 0x022;
	
	/**
	 * �������¼�
	 */
	public static final int HANDLER_TRIGGERED = 0x031;
	
	/**
	 * �Ự������
	 */
	public static final int SESSION_CREATED_TRIGGERED = 0x011;
	
	/**
	 * �Ự����
	 */
	public static final int SESSION_DESTORYED_TRIGGERED = 0x012;
	
	/**
	 * �Ự�
	 */
	public static final int SESSION_ACTIVED_TRIGGERED = 0x013;
	
	/**
	 * �ỰʧЧ
	 */
	public static final int SESSION_EXPIRED_TRIGGERED = 0x014;
}
