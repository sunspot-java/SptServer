package com.sunspoter.cs.engine;

import java.util.EventObject;

/**
 * �Ự���¼�
 * @author Sunspot
 *
 */
public class CsSessionBindingEvent extends EventObject {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private Object value;
	public CsSessionBindingEvent(ICsSession session,String name) {
		// TODO Auto-generated constructor stub
		this(session,name,null);
	}
	public CsSessionBindingEvent(ICsSession session,String name,Object value){
		super(session);
		this.name = name;
		this.value = value;
	}
	public String getName() {
		return name;
	}
	public Object getValue() {
		return value;
	}
}
