package com.sunspoter.cs.engine;

/**
 * Э���ʽ�����쳣
 * @author jz song
 *
 */
public class ProtocolFormatException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ProtocolFormatException(String msg){
		super(msg);
	}
}
