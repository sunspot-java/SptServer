package com.sunspoter.cs.codec.xml.support;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import com.sunspoter.cs.codec.MessageAnalyseException;
import com.sunspoter.cs.codec.MessageBuildException;
import com.sunspoter.cs.codec.xml.ICsXmlBuilder;
import com.sunspoter.cs.msg.ICsMessage;

/**
 * ��Message��getter���й���XML�������
 * 
 * @author jz song
 * 
 */
public class BeanXmlBuilder implements ICsXmlBuilder {
	private XMLOutputter xmlOutputter;

	public BeanXmlBuilder() {
		this.xmlOutputter = new XMLOutputter();
	}

	public String build(ICsMessage<?> msg) throws MessageBuildException {
		String xmlString = "";
		Document doc = new Document();
		Element root = new Element("SpeakSky");
		root.setAttribute("Type", msg.getClass().getCanonicalName());
		doc.addContent(root.detach());
		if (msg == null) {
			xmlString = xmlOutputter.outputString(doc);
		} else {
			Element ele = null;
			try {
				ele = this.buildElement(msg, null);
				root.addContent(ele);
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				throw new MessageBuildException(e.getClass()+" : "+e.getMessage());
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				throw new MessageBuildException(e.getClass()+" : "+e.getMessage());
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				throw new MessageBuildException(e.getClass()+" : "+e.getMessage());
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				throw new MessageBuildException(e.getClass()+" : "+e.getMessage());
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				throw new MessageBuildException(e.getClass()+" : "+e.getMessage());
			}
			xmlString = xmlOutputter.outputString(doc);
		}
		doc = null;
		root = null;
		return xmlString;
	}

	private Element buildElement(Object object, String name)
			throws SecurityException, NoSuchMethodException,
			IllegalArgumentException, IllegalAccessException,
			InvocationTargetException {
		Class<?> clazz = object.getClass();
		Field[] fields = clazz.getDeclaredFields();
		Element element = new Element(name == null ? clazz.getSimpleName()
				: name);
		for (int i = 0; i < fields.length; i++) {
			Field field = fields[i];
			String fieldName = field.getName();
			char firstChar = fieldName.charAt(0);
			char firstCharUpper = Character.toUpperCase(firstChar);
			String itemName = fieldName.replaceFirst(String.valueOf(firstChar),
					String.valueOf(firstCharUpper));
			Method method = null;
			try{
				method = clazz.getMethod("get" + itemName);
			}	catch(NoSuchMethodException e){
			}
			if (method == null) {
				continue;
			}
			Object value = method.invoke(object);
			Element fieldE = null;
			if (value == null) {
				fieldE = new Element(itemName);
				fieldE.setText(null);
				continue;
			}

			if (!ClassHelper.isBasicClassType(value.getClass())) {
				if (ClassHelper.isContainerType(value.getClass())) {
					fieldE = this.buildCollectionElement(value, itemName);
				} else {
					fieldE = this.buildElement(value, itemName);
				}
			} else {
				fieldE = new Element(itemName);
				fieldE.setText(value.toString());
			}
			element.addContent(fieldE);
		}
		return element;
	}

	private Element buildCollectionElement(Object value, String itemName)
			throws SecurityException, IllegalArgumentException,
			NoSuchMethodException, IllegalAccessException,
			InvocationTargetException {
		Element element = new Element(itemName);
		if (value.getClass().isArray()) {
			int length = Array.getLength(value);
			for (int i = 0; i < length; i++) {
				Element e = new Element("Arg");
				e.setAttribute("Index", String.valueOf(i));
				Object v = Array.get(value, i);
				if (v == null) {
					e.setText(null);
				} else if (!ClassHelper.isBasicClassType(v.getClass())) {
					if (ClassHelper.isContainerType(v.getClass())) {
						Element sub = this.buildCollectionElement(v, "Args");
						e.addContent(sub);
					} else {
						Element sub = this.buildElement(v, v.getClass()
								.getSimpleName());
						
						e.addContent(sub);
					}
				} else {
					e.setText(v.toString());
				}
				e.setAttribute("Type", v.getClass().getCanonicalName());
				element.addContent(e);
			}
		} else if (ClassHelper.isCollectionType(value.getClass())) {
			Collection<?> col = (Collection<?>) value;
			Iterator<?> it = col.iterator();
			int index = 0;
			while (it.hasNext()) {
				Object v = it.next();
				Element e = new Element("Arg");
				e.setAttribute("Index", String.valueOf(index++));
				if (!ClassHelper.isBasicClassType(v.getClass())) {
					if (ClassHelper.isContainerType(v.getClass())) {
						Element sub = this.buildCollectionElement(v, "Args");
						e.addContent(sub);
					} else {
						Element sub = this.buildElement(v, v.getClass()
								.getSimpleName());
						e.addContent(sub);
					}
				} else {
					e.setText(v.toString());
				}
				e.setAttribute("Type", v.getClass().getCanonicalName());
				element.addContent(e);
			}
		} else if (ClassHelper.isMapType(value.getClass())){
			Map<?,?> map = (Map<?, ?>) value;
			Iterator<?> it = map.keySet().iterator();
			while(it.hasNext()){
				Object k = it.next();
				Object v = map.get(k);
				Element e = new Element("Arg");
				Element ke = new Element("Key");
				if (v == null) {
					ke.setText(null);
				} else if (!ClassHelper.isBasicClassType(k.getClass())) {
					if (ClassHelper.isContainerType(k.getClass())) {
						Element sub = this.buildCollectionElement(k, "Args");
						ke.addContent(sub);
					} else {
						Element sub = this.buildElement(k, k.getClass()
								.getSimpleName());
						
						ke.addContent(sub);
					}
				} else {
					ke.setText(k.toString());
				}
				ke.setAttribute("Type", k.getClass().getCanonicalName());
				
				Element ve = new Element("Value");
				if (v == null) {
					ve.setText(null);
				} else if (!ClassHelper.isBasicClassType(v.getClass())) {
					if (ClassHelper.isContainerType(v.getClass())) {
						Element sub = this.buildCollectionElement(v, "Args");
						ve.addContent(sub);
					} else {
						Element sub = this.buildElement(v, v.getClass()
								.getSimpleName());
						ve.addContent(sub);
					}
				} else {
					ve.setText(v.toString());
				}
				ve.setAttribute("Type", v.getClass().getCanonicalName());
				
				e.addContent(ke);
				e.addContent(ve);
				element.addContent(e);
			}
		}
		return element;
	}
}
