package com.sunspoter.cs.codec.xml.support;

import java.util.Arrays;
import java.util.List;

/**
 * java��Class�ศ����
 * 
 * @author Sunspot
 * 
 */
public final class ClassHelper {
	/**
	 * ���ַ�������ǿ��ת��Ϊָ���Ļ�����������
	 * 
	 * @param value
	 *            �ַ���
	 * @param type
	 *            ������������
	 * @return ת���������
	 */
	public static Object castStringToObject(String value, Class<?> type) {
		// TODO Auto-generated method stub
		if (type == null) {
			type = String.class;
		}
		if (type == String.class) {
			return value;
		}
		if (type == int.class || type == Integer.class) {
			return Integer.parseInt(value);
		} else if (type == short.class || type == Short.class) {
			return Short.parseShort(value);
		} else if (type == long.class || type == Long.class) {
			return Long.parseLong(value);
		} else if (type == float.class || type == Float.class) {
			return Float.parseFloat(value);
		} else if (type == double.class || type == Double.class) {
			return Double.parseDouble(value);
		} else if (type == boolean.class || type == Boolean.class) {
			return Boolean.parseBoolean(value);
		}
		if (type == char.class || type == Character.class) {
			return value.charAt(0);
		}
		return value;
	}

	private static Class<?>[] basic = new Class[] { int.class, short.class,
			long.class, float.class, double.class, boolean.class, char.class,
			void.class, String.class, Integer.class, Short.class, Long.class,
			Float.class, Double.class, Boolean.class, Character.class,
			Void.class };

	/**
	 * �Ƿ��ǻ�������
	 * 
	 * @param type
	 *            ����
	 * @return ���򷵻�true
	 */
	public static boolean isBasicClassType(Class<?> type) {
		for (int i = 0; i < basic.length; i++) {
			if (type == basic[i]) {
				return true;
			}
		}
		return false;
	}

	private static Class[] containers = new Class[]{
		java.util.Map.class, java.util.List.class,
		java.util.Set.class, java.util.Queue.class,
		java.util.Collection.class, java.util.AbstractMap.class
	};
	/**
	 * �Ƿ�һ������
	 * 
	 * @param type
	 *            ����
	 * @return ���򷵻�true
	 */
	public static boolean isContainerType(Class<?> type) {
		Class<?>[] ifs = type.getInterfaces();
		return type.isArray() || find(type,containers) || find(ifs,containers);
	}

	private static final Class[] collections = new Class[]{
		java.util.List.class, java.util.Set.class,
		java.util.Queue.class, java.util.Collection.class
	};
	/**
	 * �Ƿ���Collection����
	 * 
	 * @param type
	 *            ����
	 * @return ���
	 */
	public static boolean isCollectionType(Class<?> type) {
		Class<?>[] ifs = type.getInterfaces();
		return find(ifs, collections) || find(type, collections);
	}

	/**
	 * �����Map����
	 * 
	 * @param type
	 *            ����
	 * @return ���
	 */
	public static boolean isMapType(Class<?> type) {
		Class<?>[] ifs = type.getInterfaces();
		return find(type,java.util.Map.class) || find(ifs,java.util.Map.class);
	}

	private static boolean find(Object[] objects, Object... object) {
		for (int i = 0; i < objects.length; i++) {
			for (int j = 0; j < object.length; j++) {
				if (object[j] == objects[i]) {
					return true;
				}
			}
		}
		return false;
	}
	
	private static boolean find(Object object, Object...objects){
		for(int i = 0;i<objects.length;i++){
			if(object == objects[i]){
				return true;
			}
		}
		return false;
	}

	/**
	 * ����ַ�����Ӧ������
	 * 
	 * @param type
	 *            �����ַ���
	 * @return ��Ӧ������
	 * @throws ClassNotFoundException
	 *             ��������Ͳ����ڣ����׳��쳣
	 */
	public static Class<?> getClassType(String type)
			throws ClassNotFoundException {
		// TODO Auto-generated method stub
		if (type == null || type == "") {
			return String.class;
		}
		String temp = type.trim();
		if (temp.startsWith("java.lang.String")) {
			return String.class;
		} else if (temp.startsWith("int")) {
			return int.class;
		} else if (temp.startsWith("short")) {
			return short.class;
		} else if (temp.startsWith("float")) {
			return float.class;
		} else if (temp.startsWith("double")) {
			return double.class;
		} else if (temp.startsWith("char")) {
			return char.class;
		} else if (temp.startsWith("boolean")) {
			return boolean.class;
		} else if (temp.startsWith("long")) {
			return long.class;
		}
		temp = temp.replace("[]", "");
		return Class.forName(temp);
	}
}
