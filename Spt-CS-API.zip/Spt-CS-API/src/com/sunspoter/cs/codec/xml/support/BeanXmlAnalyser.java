package com.sunspoter.cs.codec.xml.support;

import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import com.sunspoter.cs.codec.ICsAnalyser;
import com.sunspoter.cs.codec.MessageAnalyseException;
import com.sunspoter.cs.msg.ICsMessage;

public class BeanXmlAnalyser implements ICsAnalyser {
	private SAXBuilder builder;

	public BeanXmlAnalyser() {
		// TODO Auto-generated constructor stub
		this.builder = new SAXBuilder();
	}

	/*
	 * 
	 * @see
	 * com.sunspoter.cs.codec.xml.support.BeanXmlAnalyser#analyse(java.lang.
	 * String,java.lang.Class)
	 * com.sunspoter.cs.codec.xml.support
	 * .BeanXmlAnalyser#analyse(java.lang.String,java.lang.Class)
	 */
	@Override
	public ICsMessage<?> analyse(String message) throws MessageAnalyseException {
		// TODO Auto-generated method stub
		Document doc = null;
		try {
			doc = builder.build(new StringReader(message));
			Element root = doc.getRootElement();
			String clazzText = root.getAttributeValue("Type");
			Class<?> clazz = Class.forName(clazzText);
			return this.analyse(message, clazz);
		} catch (JDOMException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} finally {
			doc = null;
		}
	}

	public ICsMessage<?> analyse(String message, Class<?> clazz) throws MessageAnalyseException {
		Document doc = null;
		try {
			doc = builder.build(new StringReader(message));
			Element root = doc.getRootElement();
			Element info = root.getChild(clazz.getSimpleName());
			return (ICsMessage<?>) this.buildObject(info, clazz);
		} catch (JDOMException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new MessageAnalyseException(e.getClass()+" : "+e.getMessage());
		} finally {
			doc = null;
		}
		return null;
	}

	private Object buildObject(Element root, Class<?> clazz)
			throws InstantiationException, IllegalAccessException,
			SecurityException, NoSuchFieldException, NoSuchMethodException,
			IllegalArgumentException, InvocationTargetException,
			ClassNotFoundException {
		Object instance = clazz.newInstance();
		List<Element> list = root.getChildren();
		Iterator<Element> it = list.iterator();
		while (it.hasNext()) {
			Element item = it.next();
			String itemName = item.getName();
			String itemValue = item.getTextTrim();
			char firstChar = itemName.charAt(0);
			char firstCharLower = Character.toLowerCase(firstChar);
			String fieldName = itemName.replaceFirst(String.valueOf(firstChar),
					String.valueOf(firstCharLower));
			Field field = clazz.getDeclaredField(fieldName);
			Object value = null;
			if (!ClassHelper.isBasicClassType(field.getType())) {
				if (ClassHelper.isContainerType(field.getType())) {
					value = this.buildCollection(item, field.getType());
				} else {
					value = this.buildObject(item, field.getType());
				}
			} else {
				value = ClassHelper.castStringToObject(itemValue,
						field.getType());
			}
			Method method = clazz.getMethod("set" + itemName, field.getType());
			if (method != null) {
				method.invoke(instance, value);
			}
		}
		return instance;
	}

	private Object buildCollection(Element element, Class<?> type)
			throws ClassNotFoundException, SecurityException,
			IllegalArgumentException, InstantiationException,
			IllegalAccessException, NoSuchFieldException,
			NoSuchMethodException, InvocationTargetException {
		// TODO Auto-generated method stub
		Object object = null;
		if (type.isArray()) {
			Class<?> clazz = ClassHelper.getClassType(type.getCanonicalName());
			List<Element> args = element.getChildren();
			object = Array.newInstance(clazz, args.size());
			Iterator<Element> it = args.iterator();
			while (it.hasNext()) {
				Element item = it.next();
				String index = item.getAttributeValue("Index");
				String itemValue = item.getTextTrim();
				int i = Integer.parseInt(index);
				Object value = null;
				if (!ClassHelper.isBasicClassType(clazz)) {
					if (ClassHelper.isContainerType(clazz)) {
						value = this.buildCollection(item, clazz);
					} else {
						value = this.buildObject(
								item.getChild(clazz.getSimpleName()), clazz);
					}
				} else {
					value = ClassHelper.castStringToObject(itemValue, clazz);
				}
				Array.set(object, i, value);
			}
		} else if (ClassHelper.isCollectionType(type)) {
			Collection col = null;
			if (type == java.util.List.class) {
				col = new ArrayList();
			} else if (type == java.util.Set.class) {
				col = new HashSet();
			} else if (type == java.util.Queue.class) {
				col = new ConcurrentLinkedQueue();
			}
			if (col == null) {
				return null;
			}
			List<Element> args = element.getChildren();
			Iterator<Element> it = args.iterator();
			while (it.hasNext()) {
				Element item = it.next();
				String index = item.getAttributeValue("Index");
				String itemValue = item.getTextTrim();
				String itemType = item.getAttributeValue("Type");
				Class<?> clazz = null;
				if (itemType != null && itemType != "") {
					clazz = Class.forName(itemType);
				}
				if (clazz == null) {
					continue;
				}
				Object value = null;
				if (!ClassHelper.isBasicClassType(clazz)) {
					if (ClassHelper.isContainerType(clazz)) {
						value = this.buildCollection(item, clazz);
					} else {

						value = this.buildObject(
								item.getChild(clazz.getSimpleName()), clazz);
					}
				} else {
					value = ClassHelper.castStringToObject(itemValue, clazz);
				}
				col.add(value);
			}
			object = col;
		} else if (ClassHelper.isMapType(type)) {
			Map map = new HashMap();
			List<Element> args = element.getChildren();
			Iterator<Element> it = args.iterator();
			while (it.hasNext()) {
				Element item = it.next();
				Element k = item.getChild("Key");
				String kt = k.getAttributeValue("Type");
				String kValue = k.getTextTrim();
				Class kc = null;
				if (kt != null && kt != "") {
					kc = Class.forName(kt);
				}
				if (kc == null) {
					continue;
				}
				Object kv = null;
				if (!ClassHelper.isBasicClassType(kc)) {
					if (ClassHelper.isContainerType(kc)) {
						kv = this.buildCollection(k, kc);
					} else {
						kv = this.buildObject(k.getChild(kc.getSimpleName()),
								kc);
					}
				} else {
					kv = ClassHelper.castStringToObject(kValue, kc);
				}

				Element v = item.getChild("Value");
				String vt = v.getAttributeValue("Type");
				String vValue = v.getTextTrim();
				Class vc = null;
				if (vt != null && vt != "") {
					vc = Class.forName(vt);
				}
				if (vc == null) {
					continue;
				}
				Object vv = null;
				if (!ClassHelper.isBasicClassType(vc)) {
					if (ClassHelper.isContainerType(vc)) {
						vv = this.buildCollection(v, vc);
					} else {
						vv = this.buildObject(v.getChild(vc.getSimpleName()),
								vc);
					}
				} else {
					vv = ClassHelper.castStringToObject(vValue, vc);
				}
				map.put(kv, vv);
			}
			object = map;
		}
		return object;
	}
}
