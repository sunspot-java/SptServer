package com.sunspoter.cs.codec;

/**
 * ��Ϣ�����쳣
 * @author Sunspot
 *
 */
public class MessageBuildException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MessageBuildException() {
		// TODO Auto-generated constructor stub
		this("Message build exception");
	}
	public MessageBuildException(String message) {
		super(message);
	}
}
