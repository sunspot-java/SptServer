package com.sunspoter.cs.codec;

/**
 * ��Ϣ�����쳣
 * @author Sunspot
 *
 */
public class MessageAnalyseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MessageAnalyseException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
	public MessageAnalyseException(){
		this(null);
	}
}
