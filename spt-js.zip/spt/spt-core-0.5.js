/* ����SPTԪ�� */
var spt = {
	/**
	* ��������
	*/
	_oc:null,
	/**
	* ������
	*/
	_og:[],
	/**
	* ���󷽷�
	*/
	_of:[],
	/**
	* �߳�
	*/
	_es:null,
	NUM:['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'],
	/*
	* �Ƿ�ӵ�и÷���
	*/
	h:function(e) {
		for(var _e in this) {if(_e == e) {return true;}}
		for(var i =0;i<this._of.length;i++){if(this._of[i].n == e) {return true;}}
		return false;
	},
	/**
	* ���
	* @param n ��������
	* @param f ����
	* @param o �Ƿ�Ϊ���󷽷�
	*/
	p:function(p) {
		if(this.h(p.n)){return;}
		if(this.t(p.f) == "function" || this.t(p.f) == "object"){
			if(p.o){this._of[this._of.length] = {n:p.n,f:p.f};}
			else {eval("spt."+p.n+"=p.f;");}
		}
	},
	/**
	* �����¼�����
	* @param o DOM����
	* @param eN Event Name
	* @param f function
	*/
	e:function(o,eN,f){
		if(!o || !eN || !f) {return;}
		if(document.attachEvent) {o.attachEvent("on"+eN,f);}
		else if(document.addEventListener) {o.addEventListener(eN,f,false);}
	},
	/**
	* private �����¼�������¼��ع�
	*/
	_e:function(e){
		if(e == null) {return null;}
		var __e = {keyCode:0,ctrlKey:false,altKey:false,shiftKey:false,x:0,y:0,offsetX:0,offsetY:0,screenX:0,screenY:0,type:null};
		var ie = document.all;
		__e.code = ie?e.keyCode : e.which;
		__e.ctrl = e.ctrlKey;
		__e.alt = e.altKey;
		__e.shift = e.shifeKey;
		__e.x = e.clientX;
		__e.y = e.clientY;
		__e.offsetX = e.offsetX == null?e.layerX : e.offsetX;
		__e.offsetY = e.offsetY == null?e.layerY : e.offsetY;
		__e.screenX = e.screenX;
		__e.screenY = e.screenY;
		__e.button = ie?e.button==1?0:e.button:e.button;
		__e.type = e.type;
		return __e;
	},
	/**
	* �Ƿ�Ϊ��������
	*/
	_fN:function(fn){
		var p = /^function\s+(.*)\s*\(.*\).*/im;
		var s = p.exec(fn.constructor?fn.constructor:fn);
		return s?s[1]:null;
	},
	/**
	* ��ò�������
	* @param p parameter
	*/
	t:function(p){
		var _t = typeof p;
		if(_t == "undefined") {return null;}
		if(_t == "object") {
			var n = this._fN(p);
			if(n && n.toLowerCase()=="array") {return "array";}
			else {return "object";}
		}
		return _t;
	},
	/*
	* private Ԥ��������
	* @param f function
	*/
	_dF:function(f){
		spt.r(window).load(f);
	},
	/**
	* private �����ַ���Ϊ���󣬲���Ԫ�ش洢������������
	* ˵����1.0�汾��ֻ֧��#id,.class,<target>��ǩ�Ľ�������֧��selector
	*/
	_dS:function(s){
		var p = s.split(",");
		var i = 0;
		var c = spt._con(),k=0,cn;
		c.tag(p);
		c.g = this._og.length;
		this._og[c.g] = c;
		for(i=0;i<p.length;i++){
			var t = p[i];
			var o = null;
			if(t.indexOf("#") == 0){
				o = document.getElementById(t.substring(1));		
				if(!o){continue;}
				c.push(this._dSA(o,c.g));
			} else if (t.indexOf(".") == 0) {
				cn = t.substring(1);
				o = document.getElementsByTagName("*");
				for(k=0;k<o.length;k++){
					if(o[k].className == cn){
						c.push(this._dSA(o[k],c.g));
					}
				}
			} else {
				o = document.getElementsByTagName(t);
				for(k=0;k<o.length;k++){
					c.push(this._dSA(o[k],c.g));
				}
			}
		}
		for(i=0;i<spt._of.length;i++){
			var f = spt._of[i];
			eval("c."+f.n+"=f.f;");
		}
		return c;
	},
	/**
	* private ��DOM�������ӵ�����������
	*/
	_dSA:function(e,g){
		var i = 0;
		for(i =0;i<this._oc.length;i++){
			var _e = this._oc.get(i);
			if(_e.o.juid == e.juid){return i;}
		}
		e.juid = spt.juid();
		var dom = {o:e,i:this._oc.length,g:g,fs:spt.list(false)};
		return this._oc.add(dom);
	},
	/**
	* ��ȡ���ж������������������
	* 1.������ж���Ϊgroup������ֱ�ӷ���
	* 2.������ж���Ϊdom�������ж����������Ƿ�Ϊ1��Ԫ�أ������򷵻ظ����飬����Ϊ��dom���󴴽�group����
	* 3.������ж���Ϊ����������������£�
	*   3.1 ��dom��������Ѱ�ö���������ڣ���ִ�еڶ���
	*	3.2 ���û����dom���ҵ��ö�����Ϊ�ö��󴴽�dom�Լ�group����
	*/
	_dR:function(o){
		if(typeof o.g == "number" && spt.t(o.i) == "array") {
			if(o == this._og[o.g]){return o;}
			else {return null;}
		} else if (typeof o.o == "object" && typeof o.i == "number") {
			if(o == this._oc.get(o.i)){
				if(this._og[o.g].len == 1){return this._og[o.g];}
				else{
					var c = spt._con();
					c.g = this._og.length;
					c.push(o.i);
					o.g = c.g;
					this._og[c.g]=c;
					for(i=0;i<spt._of.length;i++){
						var f = spt._of[i];
						eval("c."+f.n+"=f.f;");
					}
					return c;
				}
			}
			else {return null;}
		} else {
			if(o == document && spt.t(o.write) != null) {
				o = document.all?document.documentElement : document.body;
			} 
			for(var i = 0;i<this._oc.length;i++){
				var _o = this._oc.get(i);
				if(_o.o == o){
					return this._dR(_o);
				}
			}
			var c = spt._con();
			c.g = this._og.length;
			c.push(this._dSA(o,c.g));
			
			for(i=0;i<this._of.length;i++){
				var f = spt._of[i];
				eval("c."+f.n+"=f.f;");
			}
			this._og[c.g] = c;
			return c;
		}
		return null;
	},
	/*
	* ��ȡ���� 
	* 1.����Ƿ������������Ԥ��������
	* 2.������ַ���������ַ������洢����������
	* 3.����Ƕ����򵽶�����������Ѱ�ö���
	*/
	r:function(s){
		if(this._oc == null){this._oc = spt.list();}
		var t = this.t(s);
		if(t == "function") {return this._dF(s);}
		else if(t == "string"){return this._dS(s);}
		else if(t == "object") {return this._dR(s);}
	},
	isN:function(v,c){
		return spt.t(v) == null || v == "" ?spt.t(c) != null && c != "" ? c :null:v;
	},
	/**
	* �����ص�����
	*/
	b:function(f) {
		if(!f || typeof f != "function") return function(){};
		var p = /^function\s*.*\s*\((.*)\)\s*{.*/i;
		var ps = p.exec(f)[1];
		var _f = null;
		eval("_f = function("+ps+"){if(f && typeof f == \"function\"){f("+ps+");}};");
		return _f;
	},
	/**
	* ת��ΪINT����
	*/
	int:function(n){
		n = parseInt(n);
		return (typeof n == "undefined" || n == null || isNaN(n)) ?0:n;
	},
	/**
	* ת��ΪFLOAT����
	*/
	float:function(n){
		n = parseFloat(n);
		return (typeof n == "undefined" || n == null || isNaN(n)) ?0.0:n;
	},
	/**
	* �����ֵID����ʽ��ʱ��Timestamp-�����
	*/
	ruid:function(){
		return new Date().getTime()+"-"+this.int(Math.random()*1000);
	},
	/**
	* ȫ��ΨһID����ʽ��T8-T4-N4-I4-I12
	*/
	juid:function(){
		var j = "",p = spt.info;
		var t = spt.hex(new Date().getTime(),12);
		var r = spt.hex(spt.int(Math.random()*65535),4);
		p = spt.shex(p.name+p.version+p.platform+p.language,16);
		j = t.substring(0,8)+"-"+t.substring(8)+"-"+r+"-"+p.substring(0,4)+"-"+p.substring(4,16);
		t = null;r=null;p=null;
		return j;
	},
	/**
	* ���������
	*/
	array:{
		addSet:function(a,n){
			for(var i =0;i<a.length;i++){
				if(a[i] == n){
					return ;
				}
			}
			a[a.length] = n;
		},
		addList:function(a,n){
			a[a.length] = n;
		},
		each:function(a,f){
			for(var i in a){
				f(a[i],i);
			}
		},
		indexOf:function(a,v){
			for(var i = 0;i<a.length;i++){
				if(a[i] == v){return i;}
			}
			return -1;
		}
	},
	/**
	* string trim
	*/
	trim:function(s){
		return s.replace(/(^\s*)|(\s*$)/g, "");
	},
	/**
	* string ltrim
	*/
	ltrim:function(){
		return s.replace(/(^\s*)/g, "");
	},
	/**
	* string rtrim
	*/
	rtrim:function(){
		return s.replace(/(\s*$)/g, "");
	},
	equals:function(s1,s2,ig){
		if(!ig){return s1 == s2;}
		return s1.toLowerCase() == s2.toLowerCase();
	},
	/**
	* ��ѯ�����query
	*/
	query:function(){
		var u,q,_p,dic,i,kv={};
		u = window.location;
		_p = /\S+\?(.*)/i;
		if(!_p.test(u)){
			return kv;
		}
		q = _p.exec(u);
		if(q.length != 2) {
			return kv;
		}
		q = String(q[1]);
		dic = q.split("&");
		_p = /(\S+)=(\S+)/i;
		for(i=0;i<dic.length;i++) {
			if(!_p.test(dic[i])) {continue;}
			q = _p.exec(dic[i]);
			if(q.length == 3) {
				eval("kv."+q[1]+" = \""+q[2]+"\"");
			}
		}
		return kv;
	},
	/**
	* ��ѯ�������Ϣ
	*/
	brower:function(){
		var n,v,p,l,_p,a,s;
		_p = /\w*(ie|chrome|firefox|safari|opera)[\s|\/]?(\d+[\.\d]*)/i;
		a = navigator.userAgent;
		s = _p.exec(a);
		n = s[1].toLowerCase();
		v = s[2].toLowerCase();
		_p = /version\/(\d+[\.\d]*)/i;
		s = _p.exec(a);
		v = s?s[1]:v;
		p = navigator.platform.toLowerCase();
		l = navigator.language?navigator.language : navigator.userLanguage;
		return {name:n,version:v,platform:p,language:l.toLowerCase()};
	},
	shex:function(s,l){
		var _s = "";
		for(var i = 0;i<s.length;i++){
			_s += s.charCodeAt(i);
		}
		return this.hex(_s,l);
	},
	oct:function(d,l){return this.num(8,d,l);},
	hex:function(d,l){return this.num(16,d,l);},
	bin:function(d,l){return this.num(2,d,l);},
	num:function(n,d,l){
		var _n = spt.int(n),_d = spt.int(d),_b = 0,l = spt.int(l);r="";
		if(n<=1 || n>16){return false;}
		do{
			_b = spt.int(_d%_n);
			_d /= _n;
			r = spt.NUM[_b]+r;
		}while(_d>= 1);
		if(r.length<l){
			var c = l - r.length;
			for(var i = 0;i<c;i++){
				r = "0"+r;
			}
		}
		return r;
	},
	dec:function(b,d){
		if(spt.t(d) == null){return 0;}
		if(spt.t(b) == null || b <= 0 || b >16){return 0;}
		var r = 0,i=0,v = 0,c = 0;
		for(i=d.length-1;i>=0;i--){
			r += spt.array.indexOf(spt.NUM,d[i])*Math.pow(b,c++);
		}
		return r;
	},
	clone:function(o){
		function f(){};
		for(k in o) {
			if(typeof o[k] == "object" && o[k] != null) {
				var nb = new o[k].constructor();
				eval("f.prototype."+k+" = nb;");
			} else {
				eval("f.prototype."+k+" = o[k];");
			}
		}
		return new f();
	},
	copy:function(t,s){
		for(k in s) {
			if(typeof s[k] == "object" && s[k] != null) {
				var o = s[k];
				if(typeof o.prototype == "undefined"){
					eval("spt.copy(t."+k+",o);");
				} else {
					if(typeof t.prototype != "undefined"){
						var nb = new s[k].constructor();
						eval("t.prototype."+k+" = nb;");
					} 
				}
			} else {
				var same = false;
				eval("same = (typeof t."+k+" == typeof s[k]);");
				if(same){
					eval("t."+k+" = s[k];");
				}
			}
		}
		return t;
	}
};
spt.info = spt.brower();
/**
* private Ԫ�������
*/
spt.p({
	n:"_con",
	f:function(){
		var c = {
			i:[],//��������_oc�еĶ����±�λ��
			g:-1,//�����_og�е��±�λ��
			len:0,//������е�Ԫ�ظ���
			ts:[],//��ǩ��
			custom:{},//�ͻ�����
			/**
			* �������±����뵽����
			* @param v �����±�
			*/
			push:function(v){
				for(var _i = 0;_i<this.len;_i++){
					if(this.i[_i] == v) {return ;}
				}
				this.i[this.len++] = v;
			},
			/**
			* ���������
			* @param f ���������鷽��
			*/
			each:function(f){
				spt._oc.each(f,this.i);
			},
			/**
			* ����ǩ���ӵ���ǩ����
			* @param t ��ǩ
			*/
			tag:function(t){
				for(var i = 0;i<t.length;i++){
					this.ts[this.ts.length] = t[i];
				}
			},
			/**
			* �жϱ�ǩ����ö���ı�ǩ������Ƿ���ͬ
			* @param _ts ��ǩ��
			*/
			equal:function(_ts){
				var i = 0,j = 0,eq;
				if(_ts.length != this.ts.length){
					return false;
				}
				
				for(i=0;_ts.length;i++){
					eq = false;
					for(j=0;j<this.ts.length;j++){
						if(_ts[i] == this.ts[j]){
							eq = true;
							break;
						}
					}
					if(!eq) {return false;}
				}
				return true;
			}
		};
		return c;
	}
});

/**
* ӳ��
*/
spt.p({
	n:"map",
	f:function(){
		var m = {
			_ks:[],
			_vs:[],
			length:0,
			_indexOfKeys:function(k){
				for(var i = 0;i<this.length;i++){
					if((typeof this._ks[i]) == (typeof k) && this._ks[i] == k){
						return i;
					}
				}
				return -1;
			},
			containsKey:function(k){
				return this._indexOfKeys(k) != -1;
			},
			put:function(k,v){
				var i = this._indexOfKeys(k);
				if(i == -1){
					this._ks[this.length] = k;
					this._vs[this.length] = v;
					this.length++;
				} else {
					this._vs[i] = v;
				}
			},
			get:function(k){
				if(this.length <= 0 ){
					return null;
				}
				var i = this._indexOfKeys(k);
				if(i == -1){
					return null;
				}
				return this._vs[i];
			},
			remove:function(k){
				var i = this._indexOfKeys(k);
				if(i == -1){
					return false;
				}
				for(var _i = i;_i<this.length-1;_i++){
					this._ks[_i] = this._ks[_i+1];
					this._vs[_i] = this._vs[_i+1];
				}
				this._ks[this.length-1] = null;
				this._vs[this.length-1] = null;
				this.length--;
				return true;
			},
			clear:function(){
				for(var i = 0;i<this.length;i++){
					this._ks[i] = null;
					this._vs[i] = null;
				}
				this.length= 0;
			},
			keys:function(){
				var ks = [];
				for(var i = 0;i<this.length;i++){
					ks[i] = this._ks[i];
				}
				return ks;
			},
			values:function(){
				var vs=[];
				for(var i = 0;i<this.length;i++){vs[i] = this._vs[i];}
				return vs;
			},
			each:function(f){
				for(var i =0;i<this.length;i++){
					f(this._ks[i],this._vs[i]);
				}
			}

		};
		return m;
	}
});

/**
* �б�
*/
spt.p({
	n:"list",
	f:function(r){
		var l = {
			_ns:[],
			repeat:true,
			length:0,
			add:function(n){
				var i = this.indexOf(n);
				if(!this.repeat){if(i != -1) return i;}
				this._ns[this.length++] = n;
				return this.length-1;
			},
			get:function(i) {
				i = spt.int(i);
				if(i<0 || i > this.length-1) {return null;}
				return this._ns[i];
			},
			remove:function(i) {
				if(spt.t(i) == "array") {
					i.sort();i.reverse();
					for(var _i = 0 ;_i<i.length;_i++){
						this.remove(i[_i]);
					}
					return true;
				} else if (spt.t(i) == "object") {
					var k = [];
					for(var j = 0;j<this.length;j++){
						if(this._ns[j] == i){
							spt.array.addList(k,j);
						}
					}
					return this.remove(k);
				} else{
					i = spt.int(i);
				}
				if(i<0 || i > this.length) {return false;}
				for(var j = i;j<this.length-1;j++) {
					this._ns[j] = this._ns[j+1];
				}
				this._ns[--this.length] = null;
				return true;
			},
			clear:function() {
				for(var i = 0;i<this._ns.length;i++) {this._ns[i] = null;}
				this.length = 0;
			},
			indexOf:function(n) {
				for(var i = 0;i<this.length;i++) {if(this._ns[i] == n) {return i;}}
				return -1;
			},
			lastIndexOf:function(n) {
				for(var i = this.length-1;i>=0;i--) {if(this._ns[i] == n) {return i;}}
				return -1;
			},
			replace:function(i,n) {
				i = spt.int(i);
				if(i<0 || i > this.length-1) {return false;}
				this._ns[i] = n;
			},
			toArray:function() {
				var _arr = [];
				for(var i = 0;i<this.length;i++) {_arr[i]=this._ns[i];}
				return _arr;
			},
			each:function(f,is){
				if(spt.t(f) != "function"){return false;}
				var i = 0,k=0;
				for(;i<this.length;i++){
					if(is){
						for(k=0;k<is.length;k++){
							if(is[k] == i) {f(this._ns[i],i);}
						}
					} 
					else {f(this._ns[i],i);};
				}
			}
		};
		if(typeof r != "undefined"){ l.repeat = r};
		return l;
	}
});

/**
* �¼�
*/
spt.p({
	n:"event",
	f:function(){
		if (document.all) return spt._e(window.event);
		f = this.event.caller;
		while (f != null) {
			var a = f.arguments[0];
			if (a) {
				if ((a.constructor == Event || a.constructor == MouseEvent) || a.constructor == KeyboardEvent || (typeof (a) == "object" && a.preventDefault && a.stopPropagation)) {
					return spt._e(a);
				}
			}
			f = f.caller;
		}
		return null;
	},
	o:true
});

/**
* ����
*/
spt.p({
	n:"on",
	f:function(n,f,id){
		this.each(function(e){
			var _f = spt.b((function(e){return function(){e.f = f;e.f(spt.r(e).event());};})(e));
			var _id = spt.t(id) != null?id:spt.ruid();
			var h = false;
			for(var i = 0;i<e.fs.length;i++){
				var __f = e.fs.get(i);
				if(__f.n == n && __f.id == _id){
					h = true;
					break;
				}
			}
			if(h){
				spt.r(e).un(n,id);
			}
			
			spt.e(e.o,spt.trim(n),_f);
			e.fs.add({n:n,f:_f,id:_id});
		});
	},
	o:true
});

/**
* ������ж���
*/
spt.p({
	n:"evts",
	f:function(n,id){
		if(spt.t(n) != "string") {n = "*";}
		else {n = spt.trim(n);}
		if(spt.t(id) != "string") {id = "*";}
		else{id = spt.trim(id);}

		var es = spt.map();
		this.each(function(e){
			var fs = spt.list(false);
			e.fs.each(function(f){
				if((f.n == n || n == "*") && (f.id == id || id == "*")){
					fs.add(f);
				}
			});
			es.put(spt.r(e),fs);
		});
		return es;
	},
	o:true
});

/**
* ж��ĳЩ����
*/
spt.p({
	n:"un",
	f:function(n,id){
		if(spt.t(n) != "string") {n = "*";}
		else {n = spt.trim(n);}
		if(spt.t(id) != "string") {id = "*";}
		else{id = spt.trim(id);}

		this.each(function(e){
			var ins = [];
			e.fs.each(function(ef,i){
				if(( ef.n == n || n == "*") && ( ef.id == id || id == "*")){
					if(document.attachEvent) {
						e.o.detachEvent("on"+ef.n,ef.f);
					} else if(document.addEventListener) {
						e.o.removeEventListener(ef.n,ef.f,false);
					}
				}
				spt.array.addSet(ins,i);
			});
			e.fs.remove(ins);
			ins = null;
		});
	},
	o:true
});

/**
* ���
*/
spt.p({
	n:"click",
	f:function(f,id){
		return this.on("click",f,id);
	},
	o:true
});

/**
* ˫��
*/
spt.p({
	n:"dblclick",
	f:function(f,id){
		return this.on("dblclick",f,id);
	},
	o:true
});

/**
* ����
*/
spt.p({
	n:"load",
	f:function(f,id){
		return this.on("load",f,id);
	},
	o:true
});

/**
* ����
*/
spt.p({
	n:"keypress",
	f:function(f,id){
		return this.on("keypress",f,id);
	},
	o:true
});
spt.p({
	n:"keydown",
	f:function(f,id){return this.on("keydown",f,id);},
	o:true
});

spt.p({
	n:"keyup",
	f:function(f,id){return this.on("keyup",f,id);},
	o:true
});

spt.p({
	n:"mouseup",
	f:function(f,id){return this.on("mouseup",f,id);},
	o:true
});

spt.p({
	n:"mouseover",
	f:function(f,id){return this.on("mouseover",f,id);},
	o:true
});

spt.p({
	n:"mousedown",
	f:function(f,id){return this.on("mousedown",f,id);},
	o:true
});

spt.p({
	n:"mouseenter",
	f:function(f,id){
		var ie = document.all;
		return this.on(ie?"mouseenter":"mouseover",f,id);
	},
	o:true
});

spt.p({
	n:"mouseleave",
	f:function(f,id){
		var ie = document.all;
		return this.on(ie?"mouseleave":"mouseout",f,id);
	},
	o:true
});

spt.p({
	n:"mouseout",
	f:function(f,id){
		var ie = document.all;
		return this.on("mouseout",f,id);
	},
	o:true
});
/**
* ����Timeout������
*/
spt.p({
	n:"time",
	f:function(t,c){
		if(this._es == null) {this._es = spt.list(false);}
		var e = window.setTimeout(spt.b(c),t);
		this._es.add(e);
		return e;
	}
});
/**
* ֹͣTimeout������
*/
spt.p({
	n:"stop",
	f:function(e){
		if(this._es == null) {this._es = spt.list(false);}
		if(e == null) {return ;}
		if(spt.t(e) == "string" && e == "*"){
			this._es.each(function(ex){window.clearTimeout(ex);ex=null;});
			this._es.clear();
		} else if(spt.t(e) != null){
			window.clearTimeout(e);
			this._es.remove(e);
			e = null;
		}
	}
});
spt.p({
	n:"ajax",
	f:function(p){
		var getReq = function(){
			var r = null;
			if(window.XMLHttpRequest) {
				r = new XMLHttpRequest();
			} else if (window.ActiveXObject) {
				r = new ActiveXObject("Microsoft.XMLHTTP");
			}
			return r;
		};
		var ajax = {
			option:{
				request:getReq(),
				url:'',
				params:'',
				type:'json',
				cache:true,
				method:'GET',
				async:true,
				before:function(){},
				success:function(data){},
				failure:function(status){},
				track:function(state){}
			},
			_d:function(){
				var op = this.option;
				switch(op.type) {
					case "json" :
						var json = null;
						eval("json = "+op.request.responseText);
						return json;
					case "text" :return op.request.responseText;
					case "xml" : return op.request.responseXML;
					default:
						op.type = "json";
						return this._d();
					break;
				}
			},
			service:function(){
				var t = this;
				var op = this.option;
				var rq = op.request;
				if(op.async) {
					rq.onreadystatechange = function() {
						op.track(rq.readyState);
						if(rq.readyState == 4) {
							if(rq.status == 200) {
								op.success(t._d());
							} else {
								op.failure(rq.status);
							}
						}
					};
				}
				try{
					rq.open(op.method,op.url,op.async);
				} catch(e) {
					op.failure(op.request.status);
					return ;
				}
				if(!op.cache) {
					rq.setRequestHeader("If-Modified-Since","0");
					rq.setRequestHeader("Cache-Control","no-cache");
					rq.setRequestHeader("Pragma","no-cache");
				}
				if(spt.equals(op.method,"POST",true)) {
					rq.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
					rq.send(op.params);
				} else {
					rq.send();
				}
				if(!op.async) {
					op.success(this._d());
				}
			}
		};
		ajax.option = spt.copy(ajax.option,p);
		ajax.service();
		return ajax;
	}
});