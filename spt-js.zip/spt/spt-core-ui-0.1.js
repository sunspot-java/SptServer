spt.p({
	n:"body",
	f:function(){return document.all?document.documentElement:document.body;}
});
spt.p({
	n:"html",
	f:function(h){
		var _h = "";
		this.each(function(e){
			if(spt.t(h) != null){
				e.o.innerHTML = h;
			}
			_h = e.o.innerHTML;
		});
		return _h;
	},
	o:true
});
spt.p({
	n:"hpad",
	o:true,
	f:function(){
		var p = 0;
		this.each(function(e){
			p += spt.int(e.o.style.paddingLeft)+spt.int(e.o.style.paddingRight)+spt.int(e.o.style.marginLeft)+spt.int(e.o.style.marginRight)+spt.int(e.o.style.borderLeftWidth)+spt.int(e.o.style.borderRightWidth);
		});
		return p;
	}
});
spt.p({
	n:"vpad",
	o:true,
	f:function(){
		var p = 0;
		this.each(function(e){
			p += spt.int(e.o.style.paddingTop)+spt.int(e.o.style.paddingBottom)+spt.int(e.o.style.marginTop)+spt.int(e.o.style.marginBottom)+spt.int(e.o.style.borderTopWidth)+spt.int(e.o.style.borderBottomWidth);
		});
		return p;
	}
});
spt.p({
	n:"width",
	f:function(w){
		var _w = 0;
		this.each(function(e){
			var pad = spt.int(e.o.style.paddingLeft)+spt.int(e.o.style.paddingRight)+spt.int(e.o.style.marginLeft)+spt.int(e.o.style.marginRight)+spt.int(e.o.style.borderLeftWidth)+spt.int(e.o.style.borderRightWidth);
			if(spt.t(w) != null){
				e.o.style.width = Math.abs(spt.int(w)-pad)+"px";
			}
			_w += e.o.offsetWidth;
		});
		return _w;
	},
	o:true
});
spt.p({
	n:"height",
	f:function(h){
		var _h = 0;
		this.each(function(e){
			var pad = spt.int(e.o.style.paddingTop)+spt.int(e.o.style.paddingBottom)+spt.int(e.o.style.marginTop)+spt.int(e.o.style.marginBottom)+spt.int(e.o.style.borderTopWidth)+spt.int(e.o.style.borderBottomWidth);
			if(spt.t(h) != null){
				e.o.style.height = Math.abs(spt.int(h)-pad)+"px";
			}
			_h += e.o.offsetHeight;
		});
		return _h;
	},
	o:true
});
spt.p({
	n:"innerWidth",
	o:true,
	f:function(w){
		var _w = 0;
		this.each(function(e){
			var p = spt.r(e).hpad();
			if(spt.t(w) != null){
				e.o.style.width = w+"px";
			}
			_w += e.o.offsetWidth - p;
		});
		return _w;
	}
});
spt.p({
	n:"innerHeight",
	o:true,
	f:function(h){
		var _h = 0;
		this.each(function(e){
			var p = spt.r(e).vpad();
			if(spt.t(h) != null){
				e.o.style.height = h+"px";
			}
			_h += e.o.offsetHeight - p;
		});
		return _h;
	}
});
spt.p({
	n:"scrollLeft",
	f:function(){
		return spt.body().scrollLeft;
	}
});
spt.p({
	n:"scrollTop",
	f:function(){
		return spt.body().scrollTop;
	}
});
spt.p({
	n:"addClass",
	o:true,
	f:function(c){
		this.each(function(e){
			if(e.o.className.indexOf(c) == -1){
				e.o.className += c;
			}
		});
	}
});
spt.p({
	n:"removeClass",
	o:true,
	f:function(c){
		this.each(function(e){
			e.o.className = e.o.className.replace(c,"");
		});
	}
});
spt.p({
	n:"replaceClass",
	o:true,
	f:function(c,n){
		this.each(function(e){
			e.o.className = e.o.className.replace(c,n);
		});
	}
});
spt.p({
	n:"css",
	o:true,
	f:function(c,r){
		var _r = "";
		this.each(function(e){
			if(spt.t(r) != null){
				if(c == "opacity"){e.o.style.filter="alpha(opacity:\""+r*100+"\")";e.o.style.opacity=r;}
				else {eval("e.o.style."+c+"=\""+r+"\";");}
			}
			if(c == "opacity"){_r = spt.isN(e.o.style.opacity,1);}
			else {eval("_r = e.o.style."+c+";");}
		});
		return _r;
	}
});
spt.p({
	n:"attr",
	o:true,
	f:function(k,v){
		var _v = null;
		this.each(function(e){
			if(spt.t(v) != null){e.o.setAttribute(k,v);}
			else{
				try{_v = e.o.getAttribute(k);}catch(e){}
			}
		});
		return _v;
	}
});
spt.p({
	n:"removeAttr",
	o:true,
	f:function(k){
		this.each(function(e){
			e.o.removeAttribute(k);
		});
	}
});
spt.p({
	n:"action",
	o:true,
	f:function(a){
		var _p = null,_x=null,_y=null,_w=null,_h=null,_st = null;
		var _t = 50,_pt = 150;
		var _s = 10;
		if(spt.t(a) != null){
			_p = spt.isN(a.opacity);
			_t = spt.isN(a.time,_t);
			_x = spt.isN(a.x);
			_y = spt.isN(a.y);
			_w = spt.isN(a.w);
			_h = spt.isN(a.h);
			_st = spt.isN(a.step,function(){});
		}
		this.custom.pfn = {r:0,a:0};
		var _add=(function(o){
			return function(){
				o.a++;
			};
		})(this.custom.pfn);
		var update = (function(o){
			return function(){
				var p =o.custom.pfn;
				p.r++;
				if(p.r >= p.a){
					if(spt.t(a.over) == "function"){
						o.custom.pfn = null;
						a.over(o);
					}
				}
			};
		})(this);

		var pfn = function(dom,c,t){
			if(spt.t(t) == null) {t=null;}
			var _v = spt.float(dom.css("opacity"));
			if(c) {_v += _s/100;}
			else{_v -= _s/100;}
			dom.css("opacity",_v);
			_st(dom,{opacity:_v});
			spt.stop(t);
			t = null;
			if(c){if(_v>=_p){dom.css("opacity",_p);update();return;}}
			else if(!c){if(_v<=_p){dom.css("opacity",_p);update();return;}}
			t = spt.time(_pt,function(){pfn(dom,c,t);});
		};
		
		var xfn = function(dom,c,t){
			if(spt.t(t) == null) {t=null;}
			var _v = spt.int(dom.css("left"));
			if(c) {_v += _s;}
			else{_v -= _s;}
			dom.css("left",_v+"px");
			_st(dom,{x:_v});
			spt.stop(t);
			t = null;
			if(c){if(_v>=_x){dom.css("left",_x+"px");update();return;}}
			else if(!c){if(_v<=_x){dom.css("left",_x+"px");update();return;}}
			t = spt.time(_t,function(){xfn(dom,c,t);});
		};

		var yfn = function(dom,c,t){
			if(spt.t(t) == null) {t=null;}
			var _v = spt.int(dom.css("top"));
			if(c) {_v += _s;}
			else{_v -= _s;}
			dom.css("top",_v+"px");
			_st(dom,{y:_v});
			spt.stop(t);
			t = null;
			if(c){if(_v>=_y){dom.css("top",_y+"px");update();return;}}
			else if(!c){if(_v<=_y){dom.css("top",_y+"px");update();return;}}
			t = spt.time(_t,function(){yfn(dom,c,t);});
		};
		
		var wfn = function(dom,c,t){
			if(spt.t(t) == null) {t=null;}
			var _v = spt.int(dom.width());
			if(c) {_v += _s;}
			else{_v -= _s;}
			dom.width(_v+"px");
			_st(dom,{w:_v});
			spt.stop(t);
			t = null;
			if(c){if(_v>=_w){dom.width(_w+"px");;update();return;}}
			else if(!c){if(_v<=_w){dom.width(_w+"px");update();return;}}
			t = spt.time(_t,function(){wfn(dom,c,t);});
		};

		var hfn = function(dom,c,t){
			if(spt.t(t) == null) {t=null;}
			var _v = spt.int(dom.height());
			if(c) {_v += _s;}
			else{_v -= _s;}
			dom.height(_v+"px");
			_st(dom,{h:_v});
			spt.stop(t);
			t = null;
			if(c){if(_v>=_h){dom.height(_h+"px");;update();return;}}
			else if(!c){if(_v<=_h){dom.height(_h+"px");update();return;}}
			t = spt.time(_t,function(){hfn(dom,c,t);});
		};

		this.each(function(e){
			var dom = spt.r(e);
			if(_p){_add();pfn(dom,spt.int(dom.css("opacity"))<=_p);}
			if(_x){_add();xfn(dom,spt.int(dom.css("left"))<=_x);}
			if(_y){_add();yfn(dom,spt.int(dom.css("top"))<=_y);}
			if(_w){_add();wfn(dom,spt.int(dom.width())<=_w);}
			if(_h){_add();hfn(dom,spt.int(dom.height())<=_h);}
		});
	}
});
spt.p({
	n:"show",
	o:true,
	f:function(){
		this.each(function(e){
			var dom = spt.r(e);
			var w = dom.width(), h = dom.height();
			dom.width(0);dom.height(0);
			dom.action({w:w,h:h});
		});
	}
});